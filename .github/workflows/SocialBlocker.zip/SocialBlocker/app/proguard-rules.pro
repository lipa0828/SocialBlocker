# Keep accessibility / admin receiver entry points
-keep class com.example.socialblocker.service.** { *; }
-keep class com.example.socialblocker.admin.** { *; }
-keep class com.example.socialblocker.data.** { *; }
