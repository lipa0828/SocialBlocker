package com.example.socialblocker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.example.socialblocker.ui.BlockerViewModel
import com.example.socialblocker.ui.screens.RootNav
import com.example.socialblocker.ui.theme.SocialBlockerTheme

class MainActivity : ComponentActivity() {
    private val viewModel: BlockerViewModel by viewModels {
        BlockerViewModel.Factory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SocialBlockerTheme {
                RootNav(viewModel = viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshSystemStatus()
    }
}
