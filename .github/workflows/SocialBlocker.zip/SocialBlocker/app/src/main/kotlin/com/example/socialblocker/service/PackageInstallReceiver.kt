package com.example.socialblocker.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.socialblocker.SocialBlockerApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Receives PACKAGE_ADDED / PACKAGE_REPLACED. If the freshly installed
 * package is on the blocklist (or matches a default blocked package),
 * we mark it as blocked so the AccessibilityService will close it on
 * its first launch.
 *
 * Note: PACKAGE_ADDED fires AFTER install completes. The "kill the
 * install activity mid-flow" guarantee in the spec is handled by
 * BlockerAccessibilityService scanning installer UIs (see
 * InstallerPackages). This receiver is the belt to that suspenders.
 */
class PackageInstallReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_PACKAGE_ADDED &&
            action != Intent.ACTION_PACKAGE_REPLACED
        ) return

        val pkg = intent.data?.schemeSpecificPart ?: return
        Log.i(TAG, "Package event $action -> $pkg")

        // Mark the newly installed package as blocked if its package id
        // is in the default blocked set (e.g., user just sideloaded
        // TikTok). The user can still flip it off via the settings
        // screen — but only after entering their password.
        val app = context.applicationContext as SocialBlockerApp
        val repo = app.container.blocklistRepository
        val defaults =
            context.resources.getStringArray(
                com.example.socialblocker.R.array.default_blocked_packages
            ).toSet()
        if (pkg in defaults) {
            CoroutineScope(Dispatchers.IO).launch {
                repo.setBlocked(pkg, true)
            }
        }
    }

    companion object {
        private const val TAG = "SocialBlocker"
    }
}
