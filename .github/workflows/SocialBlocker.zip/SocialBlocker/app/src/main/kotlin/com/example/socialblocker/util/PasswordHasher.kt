package com.example.socialblocker.util

import java.security.MessageDigest
import java.security.SecureRandom

/**
 * SHA-256(salt || password). Salt is generated on first use. We keep the
 * salt in DataStore alongside the hash. Iteration count is fixed (1)
 * because the salt + Android keystore-grade randomness already prevents
 * naive offline attacks for a single-user, single-device app.
 *
 * If you want stronger hashing, swap this for PBKDF2WithHmacSHA256.
 */
object PasswordHasher {

    fun newSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return bytes.toHex()
    }

    fun hash(password: String, salt: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(salt.hexToBytes())
        val out = md.digest(password.toByteArray(Charsets.UTF_8))
        return out.toHex()
    }

    fun verify(password: String, salt: String, expectedHash: String): Boolean =
        hash(password, salt) == expectedHash

    private fun ByteArray.toHex(): String =
        joinToString("") { b -> "%02x".format(b) }

    private fun String.hexToBytes(): ByteArray {
        require(length % 2 == 0) { "hex string must be even length" }
        return ByteArray(length / 2) { i ->
            ((Character.digit(this[i * 2], 16) shl 4) +
                Character.digit(this[i * 2 + 1], 16)).toByte()
        }
    }
}
