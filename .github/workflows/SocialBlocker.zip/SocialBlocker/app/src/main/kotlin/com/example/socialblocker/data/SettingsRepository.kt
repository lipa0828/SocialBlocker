package com.example.socialblocker.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.socialblocker.util.PasswordHasher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("blocker_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val PASSWORD_HASH = stringPreferencesKey("password_hash")
        val PASSWORD_SALT = stringPreferencesKey("password_salt")
    }

    val passwordSet: Flow<Boolean> =
        context.dataStore.data.map { it[Keys.PASSWORD_HASH] != null }

    suspend fun isPasswordSet(): Boolean =
        context.dataStore.data.first()[Keys.PASSWORD_HASH] != null

    suspend fun setPassword(plain: String) {
        val salt = PasswordHasher.newSalt()
        val hash = PasswordHasher.hash(plain, salt)
        context.dataStore.edit { prefs ->
            prefs[Keys.PASSWORD_SALT] = salt
            prefs[Keys.PASSWORD_HASH] = hash
        }
    }

    suspend fun verifyPassword(plain: String): Boolean {
        val prefs: Preferences = context.dataStore.data.first()
        val salt = prefs[Keys.PASSWORD_SALT] ?: return false
        val hash = prefs[Keys.PASSWORD_HASH] ?: return false
        return PasswordHasher.verify(plain, salt, hash)
    }
}
