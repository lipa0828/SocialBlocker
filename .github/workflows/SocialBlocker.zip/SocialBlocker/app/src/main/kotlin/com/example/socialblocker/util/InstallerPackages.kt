package com.example.socialblocker.util

/**
 * Packages that show install / store UI. When the accessibility service
 * sees one of these in the foreground AND a blocked package name appears
 * inside the on-screen text, we redirect the user to the home screen.
 */
object InstallerPackages {

    /** Stores / installer UIs that might show "Install this blocked app". */
    val STORE_OR_INSTALLER = setOf(
        "com.android.vending",                       // Google Play Store
        "com.google.android.packageinstaller",        // Old Package Installer
        "com.android.packageinstaller",               // AOSP Package Installer
        "com.google.android.permissioncontroller",    // Newer permission controller
        "com.huawei.appmarket",                       // Huawei AppGallery
        "com.sec.android.app.samsungapps",            // Samsung Galaxy Store
        "com.amazon.venezia",                         // Amazon Appstore
        "com.aurora.store",                           // Aurora Store
        "org.fdroid.fdroid"                           // F-Droid
    )

    /** Common browser packages. */
    val BROWSERS = setOf(
        "com.android.chrome",
        "com.chrome.beta",
        "com.chrome.dev",
        "org.mozilla.firefox",
        "com.brave.browser",
        "com.microsoft.emmx",
        "com.opera.browser",
        "com.opera.mini.native",
        "com.sec.android.app.sbrowser",
        "com.duckduckgo.mobile.android"
    )
}
