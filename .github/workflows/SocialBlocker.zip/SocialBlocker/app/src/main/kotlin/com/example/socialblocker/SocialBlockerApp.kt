package com.example.socialblocker

import android.app.Application
import com.example.socialblocker.data.AppContainer

class SocialBlockerApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(applicationContext)
    }
}
