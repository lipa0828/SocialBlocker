package com.example.socialblocker.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.socialblocker.MainActivity
import com.example.socialblocker.R

/**
 * Fires on boot. Accessibility services restart themselves automatically
 * if they were enabled, but we can't programmatically re-enable them if
 * the user turned them off. We just check the state and, if disabled,
 * post a notification that opens MainActivity so the user can fix it.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action !in BOOT_ACTIONS) return
        if (BlockerAccessibilityService.IsEnabled.get()) return

        showReenableNotification(context)
    }

    private fun showReenableNotification(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE)
            as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Social Blocker status",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "Reminders to re-enable blocking." }
            nm.createNotificationChannel(channel)
        }

        val pi = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val n = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText("Social Blocker is OFF. Tap to re-enable.")
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()

        nm.notify(NOTIF_ID, n)
    }

    companion object {
        private const val CHANNEL_ID = "blocker_status"
        private const val NOTIF_ID = 1001
        private val BOOT_ACTIONS = setOf(
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            Intent.ACTION_MY_PACKAGE_REPLACED
        )
    }
}
