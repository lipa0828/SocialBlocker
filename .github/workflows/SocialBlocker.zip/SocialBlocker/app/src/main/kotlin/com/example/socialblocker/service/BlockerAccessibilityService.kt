package com.example.socialblocker.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.socialblocker.SocialBlockerApp
import com.example.socialblocker.data.BlocklistRepository
import com.example.socialblocker.util.InstallerPackages
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * The brain of the blocker.
 *
 *  - On every TYPE_WINDOW_STATE_CHANGED event we read the foreground
 *    package. If it's on the blocklist we kick the user back to the
 *    home screen.
 *  - On store / browser / installer screens we additionally scan the
 *    visible text. If we see the package name OR a recognisable label
 *    of a blocked app we also bail out.
 *  - We throttle ourselves to avoid bouncing the user away forever
 *    while a blocked window is still being torn down.
 */
class BlockerAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private lateinit var repo: BlocklistRepository

    @Volatile
    private var blockedPackages: Set<String> = emptySet()

    // Avoid double-firing for the same package within this window.
    private var lastBlockedPkg: String? = null
    private var lastBlockedAt: Long = 0L

    override fun onCreate() {
        super.onCreate()
        val container = (application as SocialBlockerApp).container
        repo = container.blocklistRepository

        // Keep an in-memory snapshot of the blocklist, refreshed reactively.
        scope.launch {
            repo.observeBlocklistAsSet()
                .stateIn(this, SharingStarted.Eagerly, repo.blockedPackagesSync())
                .collect { newSet -> blockedPackages = newSet }
        }
        Log.i(TAG, "Blocker accessibility service created.")
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i(TAG, "Service connected. Blocking ${blockedPackages.size} packages.")
        IsEnabled.set(true)
    }

    override fun onDestroy() {
        IsEnabled.set(false)
        scope.cancel()
        super.onDestroy()
    }

    override fun onInterrupt() {
        // No-op.
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pkg = event.packageName?.toString() ?: return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> handleForeground(pkg, event)
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> handleContent(pkg, event)
        }
    }

    private fun handleForeground(pkg: String, event: AccessibilityEvent) {
        if (pkg in blockedPackages) {
            kickToHome(reason = "blocked app foregrounded: $pkg", pkg = pkg)
            return
        }
        // If they opened a store/browser/installer, scan its content.
        if (pkg in InstallerPackages.STORE_OR_INSTALLER ||
            pkg in InstallerPackages.BROWSERS
        ) {
            scanWindowForBlockedReferences(event)
        }
    }

    private fun handleContent(pkg: String, event: AccessibilityEvent) {
        if (pkg in InstallerPackages.STORE_OR_INSTALLER ||
            pkg in InstallerPackages.BROWSERS
        ) {
            scanWindowForBlockedReferences(event)
        }
    }

    /**
     * Walks the visible accessibility tree and checks whether any text
     * matches a blocked package id (e.g. "com.instagram.android") or
     * the part after the last dot ("instagram"). Cheap and good enough
     * for what install / store pages look like.
     */
    private fun scanWindowForBlockedReferences(event: AccessibilityEvent) {
        val root: AccessibilityNodeInfo = event.source ?: rootInActiveWindow ?: return
        val tokens = buildSet {
            for (pkg in blockedPackages) {
                add(pkg.lowercase())
                val tail = pkg.substringAfterLast('.').lowercase()
                if (tail.isNotEmpty()) add(tail)
            }
        }
        if (tokens.isEmpty()) return

        if (subtreeMentions(root, tokens)) {
            kickToHome(reason = "install/store/browser referenced a blocked app",
                pkg = event.packageName?.toString() ?: "?")
        }
    }

    private fun subtreeMentions(node: AccessibilityNodeInfo?, tokens: Set<String>): Boolean {
        if (node == null) return false
        val text = (node.text?.toString() ?: "") + " " +
            (node.contentDescription?.toString() ?: "")
        val haystack = text.lowercase()
        if (tokens.any { it.length >= 4 && haystack.contains(it) }) return true
        for (i in 0 until node.childCount) {
            if (subtreeMentions(node.getChild(i), tokens)) return true
        }
        return false
    }

    private fun kickToHome(reason: String, pkg: String) {
        val now = SystemClock.elapsedRealtime()
        if (pkg == lastBlockedPkg && now - lastBlockedAt < THROTTLE_MS) return
        lastBlockedPkg = pkg
        lastBlockedAt = now

        Log.i(TAG, "Bouncing to home: $reason")
        // Try the system back action first — closes most "Install" dialogs.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try { performGlobalAction(GLOBAL_ACTION_BACK) } catch (_: Throwable) {}
        }
        val home = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        try {
            startActivity(home)
        } catch (t: Throwable) {
            Log.w(TAG, "Could not start home: ${t.message}")
        }
    }

    companion object {
        private const val TAG = "SocialBlocker"
        private const val THROTTLE_MS = 1500L
    }

    /**
     * Tiny holder so the UI can ask "is the service running right now?"
     * without binding to it. The accessibility framework sets this for
     * us via lifecycle callbacks.
     */
    object IsEnabled {
        @Volatile private var enabled: Boolean = false
        fun set(value: Boolean) { enabled = value }
        fun get(): Boolean = enabled
    }
}
