package com.example.socialblocker.ui

import android.app.Application
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.text.TextUtils
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.socialblocker.SocialBlockerApp
import com.example.socialblocker.admin.BlockerDeviceAdminReceiver
import com.example.socialblocker.data.BlocklistRepository
import com.example.socialblocker.data.InstalledApp
import com.example.socialblocker.data.SettingsRepository
import com.example.socialblocker.service.BlockerAccessibilityService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class UiAppRow(
    val packageName: String,
    val label: String,
    val isBlocked: Boolean,
    val isAllowlisted: Boolean
)

data class SystemStatus(
    val accessibilityEnabled: Boolean = false,
    val deviceAdminActive: Boolean = false
)

class BlockerViewModel(
    app: Application,
    private val blocklist: BlocklistRepository,
    private val settings: SettingsRepository
) : AndroidViewModel(app) {

    private val ctx: Context get() = getApplication()

    private val _installed = MutableStateFlow<List<InstalledApp>>(emptyList())
    val installed = _installed.asStateFlow()

    val blockedSet: StateFlow<Set<String>> =
        blocklist.observeBlocklistAsSet()
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    val passwordSet: StateFlow<Boolean> =
        settings.passwordSet.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    private val _systemStatus = MutableStateFlow(SystemStatus())
    val systemStatus = _systemStatus.asStateFlow()

    val rows: StateFlow<List<UiAppRow>> =
        combine(installed, blockedSet) { apps, blocked ->
            val allowlist = ctx.resources
                .getStringArray(com.example.socialblocker.R.array.allowlist_packages)
                .toSet()
            apps.map { a ->
                UiAppRow(
                    packageName = a.packageName,
                    label = a.label,
                    isBlocked = a.packageName in blocked,
                    isAllowlisted = a.packageName in allowlist
                )
            }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        viewModelScope.launch {
            blocklist.seedDefaultsIfEmpty()
            _installed.value = blocklist.listInstalledApps()
        }
    }

    fun refreshSystemStatus() {
        _systemStatus.value = SystemStatus(
            accessibilityEnabled = isAccessibilityServiceEnabled(ctx),
            deviceAdminActive = isDeviceAdminActive(ctx)
        )
    }

    fun setBlocked(pkg: String, blocked: Boolean) {
        viewModelScope.launch { blocklist.setBlocked(pkg, blocked) }
    }

    // ----- Password management -----

    suspend fun isPasswordSet(): Boolean = settings.isPasswordSet()
    suspend fun setPassword(plain: String) = settings.setPassword(plain)
    suspend fun verifyPassword(plain: String): Boolean = settings.verifyPassword(plain)

    // ----- System helpers -----

    private fun isAccessibilityServiceEnabled(ctx: Context): Boolean {
        val expected = ComponentName(
            ctx, BlockerAccessibilityService::class.java
        ).flattenToString()

        val enabled = Settings.Secure.getInt(
            ctx.contentResolver,
            Settings.Secure.ACCESSIBILITY_ENABLED, 0
        ) == 1
        if (!enabled) return false

        val flat = Settings.Secure.getString(
            ctx.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':').apply { setString(flat) }
        for (token in splitter) {
            if (token.equals(expected, ignoreCase = true)) return true
        }
        return false
    }

    private fun isDeviceAdminActive(ctx: Context): Boolean {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE)
            as DevicePolicyManager
        return dpm.isAdminActive(BlockerDeviceAdminReceiver.componentName(ctx))
    }

    class Factory(private val app: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val container = (app as SocialBlockerApp).container
            return BlockerViewModel(
                app,
                container.blocklistRepository,
                container.settingsRepository
            ) as T
        }
    }
}
