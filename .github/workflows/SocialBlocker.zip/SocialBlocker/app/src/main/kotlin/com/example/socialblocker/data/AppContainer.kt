package com.example.socialblocker.data

import android.content.Context

/**
 * Lightweight DI container. Held by SocialBlockerApp, so any component
 * that has the Application reference can reach the database, repos, etc.
 */
class AppContainer(context: Context) {
    private val db = AppDatabase.get(context)
    val blocklistRepository: BlocklistRepository =
        BlocklistRepository(context, db.blockedAppDao())
    val settingsRepository: SettingsRepository = SettingsRepository(context)
}
