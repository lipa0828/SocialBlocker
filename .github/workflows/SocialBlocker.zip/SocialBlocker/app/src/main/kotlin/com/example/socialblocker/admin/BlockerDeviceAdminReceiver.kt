package com.example.socialblocker.admin

import android.app.admin.DeviceAdminReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Marks Social Blocker as a device administrator. The user must
 * deactivate admin rights before they can uninstall the app -- and
 * the in-app "Disable admin" button is password-protected.
 *
 * onDisableRequested() returns a warning string the system shows
 * before the user can deactivate from system settings.
 */
class BlockerDeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        Log.i(TAG, "Device admin enabled.")
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        return "Deactivating Social Blocker as a device admin will let it be " +
            "uninstalled. Use the in-app Disable button (password protected) " +
            "if you really want to remove blocking."
    }

    override fun onDisabled(context: Context, intent: Intent) {
        Log.i(TAG, "Device admin disabled.")
    }

    companion object {
        private const val TAG = "SocialBlocker"

        fun componentName(context: Context): ComponentName =
            ComponentName(context, BlockerDeviceAdminReceiver::class.java)
    }
}
