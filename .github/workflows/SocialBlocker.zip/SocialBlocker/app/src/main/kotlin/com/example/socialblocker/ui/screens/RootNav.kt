package com.example.socialblocker.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import com.example.socialblocker.ui.BlockerViewModel
import kotlinx.coroutines.launch

sealed interface Screen {
    data object SetupPassword : Screen
    data object Unlock : Screen
    data object Home : Screen
}

@Composable
fun RootNav(viewModel: BlockerViewModel) {
    val passwordSet by viewModel.passwordSet.collectAsState()
    var unlocked by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val current: Screen = when {
        !passwordSet -> Screen.SetupPassword
        !unlocked    -> Screen.Unlock
        else         -> Screen.Home
    }

    when (current) {
        Screen.SetupPassword -> SetupPasswordScreen(
            onSubmit = { plain ->
                viewModel.setPassword(plain)
                unlocked = true
            }
        )
        Screen.Unlock -> UnlockScreen(
            verify = { plain -> viewModel.verifyPassword(plain) },
            onUnlocked = { unlocked = true }
        )
        Screen.Home -> HomeScreen(
            viewModel = viewModel,
            verifyPassword = { plain -> viewModel.verifyPassword(plain) }
        )
    }
}
