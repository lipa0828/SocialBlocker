package com.example.socialblocker.data

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.example.socialblocker.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

data class InstalledApp(
    val packageName: String,
    val label: String,
    val isSystem: Boolean
)

class BlocklistRepository(
    private val context: Context,
    private val dao: BlockedAppDao
) {

    /** Set of allowlisted packages that should never be blocked by default. */
    private val allowlist: Set<String> by lazy {
        context.resources.getStringArray(R.array.allowlist_packages).toSet()
    }

    /** Default blocked packages declared in strings.xml. */
    private val defaultBlocked: Set<String> by lazy {
        context.resources.getStringArray(R.array.default_blocked_packages).toSet()
    }

    fun observeBlocklistAsSet(): Flow<Set<String>> =
        dao.observeBlockedPackages().map { it.toSet() }

    fun blockedPackagesSync(): Set<String> = dao.blockedPackagesSync().toSet()

    fun observeAll(): Flow<List<BlockedAppEntity>> = dao.observeAll()

    suspend fun setBlocked(packageName: String, blocked: Boolean) {
        if (blocked && packageName in allowlist) return // hard guard
        dao.upsert(BlockedAppEntity(packageName, blocked))
    }

    /** Reads every installed launchable app and unions with default list. */
    suspend fun listInstalledApps(): List<InstalledApp> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val flags = PackageManager.GET_META_DATA
        val all = pm.getInstalledApplications(flags)
        all.mapNotNull { info ->
            // Skip ourselves
            if (info.packageName == context.packageName) return@mapNotNull null
            // Keep only apps the user can launch (have a launch intent)
            val launchable = pm.getLaunchIntentForPackage(info.packageName) != null
            if (!launchable) return@mapNotNull null
            InstalledApp(
                packageName = info.packageName,
                label = pm.getApplicationLabel(info).toString(),
                isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            )
        }.sortedBy { it.label.lowercase() }
    }

    /** First-run: seed the database with the default blocked set. */
    suspend fun seedDefaultsIfEmpty() = withContext(Dispatchers.IO) {
        val installed = listInstalledApps().map { it.packageName }.toSet()
        val toInsert = defaultBlocked.intersect(installed).map { pkg ->
            BlockedAppEntity(packageName = pkg, blocked = pkg !in allowlist)
        }
        if (toInsert.isNotEmpty()) {
            dao.upsertAll(toInsert)
        }
    }
}
