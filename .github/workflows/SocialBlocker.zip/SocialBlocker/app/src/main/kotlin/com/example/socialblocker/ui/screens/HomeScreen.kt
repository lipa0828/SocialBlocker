package com.example.socialblocker.ui.screens

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.socialblocker.admin.BlockerDeviceAdminReceiver
import com.example.socialblocker.ui.BlockerViewModel
import com.example.socialblocker.ui.UiAppRow
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: BlockerViewModel,
    verifyPassword: suspend (String) -> Boolean
) {
    val rows by viewModel.rows.collectAsState()
    val status by viewModel.systemStatus.collectAsState()
    val ctx = LocalContext.current

    var pendingUnblock by remember { mutableStateOf<UiAppRow?>(null) }
    var pendingDisableAdmin by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Social Blocker") })
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {

            SystemStatusCard(
                status = status,
                onEnableAccessibility = { openAccessibilitySettings(ctx) },
                onEnableDeviceAdmin = { openAddDeviceAdmin(ctx) },
                onDisableDeviceAdmin = { pendingDisableAdmin = true }
            )

            HorizontalDivider()

            Text(
                "Apps",
                modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 4.dp),
                style = MaterialTheme.typography.titleMedium
            )

            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(items = rows, key = { it.packageName }) { row ->
                    AppRow(
                        row = row,
                        onToggle = { newValue ->
                            if (!newValue && row.isBlocked) {
                                // Removing from blocklist requires password.
                                pendingUnblock = row
                            } else {
                                viewModel.setBlocked(row.packageName, newValue)
                            }
                        }
                    )
                }
            }
        }

        if (pendingUnblock != null) {
            PasswordDialog(
                title = "Confirm unblock",
                message = "Unblocking \"${pendingUnblock!!.label}\" requires your password.",
                verify = verifyPassword,
                onSuccess = {
                    viewModel.setBlocked(pendingUnblock!!.packageName, false)
                    pendingUnblock = null
                },
                onDismiss = { pendingUnblock = null }
            )
        }
        if (pendingDisableAdmin) {
            PasswordDialog(
                title = "Disable device admin",
                message = "After admin is removed the app can be uninstalled. " +
                    "Enter your password to continue.",
                verify = verifyPassword,
                onSuccess = {
                    val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE)
                        as DevicePolicyManager
                    dpm.removeActiveAdmin(BlockerDeviceAdminReceiver.componentName(ctx))
                    viewModel.refreshSystemStatus()
                    pendingDisableAdmin = false
                },
                onDismiss = { pendingDisableAdmin = false }
            )
        }
    }
}

@Composable
private fun SystemStatusCard(
    status: com.example.socialblocker.ui.SystemStatus,
    onEnableAccessibility: () -> Unit,
    onEnableDeviceAdmin: () -> Unit,
    onDisableDeviceAdmin: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(Modifier.padding(16.dp)) {
            StatusLine(
                label = "Accessibility service",
                ok = status.accessibilityEnabled,
                actionLabel = if (status.accessibilityEnabled) null else "Enable",
                onAction = onEnableAccessibility
            )
            Spacer(Modifier.height(8.dp))
            StatusLine(
                label = "Device admin",
                ok = status.deviceAdminActive,
                actionLabel = if (status.deviceAdminActive) "Disable" else "Enable",
                onAction = if (status.deviceAdminActive) onDisableDeviceAdmin
                           else onEnableDeviceAdmin
            )
        }
    }
}

@Composable
private fun StatusLine(
    label: String,
    ok: Boolean,
    actionLabel: String?,
    onAction: () -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(10.dp)
                .padding(end = 6.dp)
        ) {
            // simple status dot via background drawable
        }
        Text(
            text = (if (ok) "✓ " else "✗ ") + label,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
        if (actionLabel != null) {
            Button(onClick = onAction) { Text(actionLabel) }
        }
    }
}

@Composable
private fun AppRow(row: UiAppRow, onToggle: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f)) {
            Text(row.label, style = MaterialTheme.typography.bodyLarge)
            Text(
                row.packageName + if (row.isAllowlisted) " · allowlisted" else "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(
            checked = row.isBlocked,
            onCheckedChange = onToggle,
            enabled = !row.isAllowlisted
        )
    }
}

@Composable
private fun PasswordDialog(
    title: String,
    message: String,
    verify: suspend (String) -> Boolean,
    onSuccess: () -> Unit,
    onDismiss: () -> Unit
) {
    var pwd by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text(message)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = pwd,
                    onValueChange = { pwd = it; err = null },
                    label = { Text("Password") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )
                if (err != null) {
                    Spacer(Modifier.height(4.dp))
                    Text(err!!, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                scope.launch {
                    if (verify(pwd)) onSuccess() else err = "Wrong password."
                }
            }) { Text("Confirm") }
        },
        dismissButton = {
            Button(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ===== Intents =====

private fun openAccessibilitySettings(ctx: Context) {
    ctx.startActivity(
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
    )
}

private fun openAddDeviceAdmin(ctx: Context) {
    val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
        putExtra(
            DevicePolicyManager.EXTRA_DEVICE_ADMIN,
            BlockerDeviceAdminReceiver.componentName(ctx)
        )
        putExtra(
            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
            "Activating device admin prevents Social Blocker from being " +
                "uninstalled until you disable it inside the app."
        )
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    ctx.startActivity(intent)
}
