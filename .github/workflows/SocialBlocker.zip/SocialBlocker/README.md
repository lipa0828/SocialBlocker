# Social Blocker

A self-binding Android app that uses an `AccessibilityService` and the
Device Admin API to keep you out of social-media apps you've put on a
personal blocklist (Telegram, Instagram, TikTok, Facebook, X/Twitter,
Snapchat, etc.). WhatsApp is allowlisted by default.

Min SDK 26 · Target SDK 34 · Kotlin · Jetpack Compose · Room · DataStore.

## What it does

- **Blocking.** An `AccessibilityService` watches `TYPE_WINDOW_STATE_CHANGED`
  events. If a blocked package comes to the foreground we immediately
  send the user back to the home screen (`Intent.CATEGORY_HOME`,
  `FLAG_ACTIVITY_NEW_TASK | FLAG_ACTIVITY_CLEAR_TASK`).
- **Install blocker.** When the foreground app is the Play Store, an
  installer UI, or a browser, we walk the accessibility tree for the
  visible text. If we see a blocked package id or a recognizable tail
  ("instagram", "tiktok", ...) we also send the user home — killing the
  install flow before it finishes. A `PACKAGE_ADDED` receiver is the
  belt-and-suspenders: anything that does slip through gets flipped to
  blocked the moment it's installed.
- **Password-gated.** Removing an app from the blocklist or revoking
  device admin both pop a password dialog. The password is set on
  first launch, hashed with SHA-256 over a 128-bit random salt, and
  stored in Preferences DataStore.
- **Hard to uninstall.** The app declares itself as a `DeviceAdminReceiver`.
  Android refuses to uninstall an active device admin. The only way to
  deactivate admin is the password-gated button inside the app.
- **Persistence.** A `BOOT_COMPLETED` receiver posts a "Re-enable
  blocking" notification if the accessibility service has been turned
  off. Accessibility services auto-restart on boot when they were
  previously enabled.

## File tree

```
SocialBlocker/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── README.md
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── kotlin/com/example/socialblocker/
        │   ├── MainActivity.kt
        │   ├── SocialBlockerApp.kt
        │   ├── admin/
        │   │   └── BlockerDeviceAdminReceiver.kt
        │   ├── data/
        │   │   ├── AppContainer.kt
        │   │   ├── AppDatabase.kt
        │   │   ├── BlockedAppDao.kt
        │   │   ├── BlockedAppEntity.kt
        │   │   ├── BlocklistRepository.kt
        │   │   └── SettingsRepository.kt
        │   ├── service/
        │   │   ├── BlockerAccessibilityService.kt
        │   │   ├── BootReceiver.kt
        │   │   └── PackageInstallReceiver.kt
        │   ├── ui/
        │   │   ├── BlockerViewModel.kt
        │   │   ├── screens/
        │   │   │   ├── HomeScreen.kt
        │   │   │   ├── RootNav.kt
        │   │   │   ├── SetupPasswordScreen.kt
        │   │   │   └── UnlockScreen.kt
        │   │   └── theme/Theme.kt
        │   └── util/
        │       ├── InstallerPackages.kt
        │       └── PasswordHasher.kt
        └── res/
            ├── drawable/ic_launcher_foreground.xml
            ├── mipmap-anydpi-v26/
            │   ├── ic_launcher.xml
            │   └── ic_launcher_round.xml
            ├── values/
            │   ├── colors.xml
            │   ├── ic_launcher_background.xml
            │   ├── strings.xml
            │   └── themes.xml
            └── xml/
                ├── accessibility_service_config.xml
                ├── data_extraction_rules.xml
                └── device_admin.xml
```

## Build (Android Studio)

1. **Open the project.** Android Studio Iguana (2023.2) or newer.
   `File → Open…` and pick the `SocialBlocker/` folder.
2. **Let Gradle sync.** Studio will download AGP 8.5.2, Kotlin 1.9.24,
   and the Compose BOM 2024.09 the first time.
3. **Install the Gradle wrapper** if Studio offers ("Use Gradle Wrapper").
   This project is ready to be built with `./gradlew assembleRelease`
   once the wrapper is in place — Studio adds the wrapper files
   (`gradlew`, `gradlew.bat`, `gradle/wrapper/*`) automatically.
4. **Pick a target device.** Either:
   - A physical device with USB debugging on (Settings → Developer options → USB debugging).
   - Or the emulator (any image API 26+).
5. **Run.** Hit ▶. Studio builds, signs with the debug key, and
   sideloads to the device.

### One-shot CLI build

```bash
cd SocialBlocker
./gradlew :app:assembleDebug         # debug APK in app/build/outputs/apk/debug/
./gradlew :app:assembleRelease       # release APK (needs signing config — see below)
```

## Signing the release APK

Debug builds are signed with Android Studio's debug key and install
straight to your phone. For a release build you need your own key.

```bash
# Generate a keystore (do this once, store the .jks file safely)
keytool -genkey -v \
    -keystore ~/social-blocker.jks \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -alias social-blocker

# Then build a release APK, signing it with that key
./gradlew :app:assembleRelease \
    -Pandroid.injected.signing.store.file=$HOME/social-blocker.jks \
    -Pandroid.injected.signing.store.password=YOUR_KS_PASSWORD \
    -Pandroid.injected.signing.key.alias=social-blocker \
    -Pandroid.injected.signing.key.password=YOUR_KEY_PASSWORD
```

The signed APK lands in `app/build/outputs/apk/release/app-release.apk`.

> Prefer keeping the signing config out of Gradle properties? Studio's
> `Build → Generate Signed Bundle / APK…` wizard does the same thing
> interactively.

## Install on your own device

```bash
# Enable "Developer options" → "USB debugging" on the phone first.
adb install -r app/build/outputs/apk/release/app-release.apk
```

If you've side-loaded another build before with the same package name
but a different signing key, uninstall the old one first:
`adb uninstall com.example.socialblocker`.

## First-run flow (on the device)

1. Open **Social Blocker**.
2. Set your master password.
3. Tap **Enable** next to "Accessibility service". Android sends you to
   the Accessibility settings screen — find Social Blocker, flip it on,
   accept the warning, then come back.
4. Tap **Enable** next to "Device admin". Confirm in the system dialog
   that appears.
5. Scroll the app list and flip on/off any package. WhatsApp is
   force-allowlisted; its switch is disabled.

Removing an app from the blocklist, or disabling device admin, will
now prompt for the password.

## Uninstalling (the intended path)

1. Open Social Blocker.
2. Disable device admin (enter password).
3. Disable the Accessibility service in system settings.
4. `adb uninstall com.example.socialblocker` (or long-press → uninstall
   on the launcher).

If you forget the password you can still uninstall, but only via
recovery mode (factory reset) — that's the whole point.

## Caveats and things to tune

- The accessibility service watches every window event. That's
  unavoidable for a foreground-app detector but means it can be
  battery-noisy on cheap devices. Tune `notificationTimeout` in
  `accessibility_service_config.xml` up if you don't need 100ms
  reactivity.
- Some OEMs (Xiaomi, Oppo, Vivo) hide an extra "Background autostart"
  permission. If blocking dies after a reboot on such devices, enable
  Autostart for Social Blocker in the vendor settings app.
- Browsers vary in how their URL bars expose text via accessibility.
  The default token scan covers the common "https://play.google.com/...?id=PKG"
  pattern and on-page app names. Add more package ids to
  `InstallerPackages.BROWSERS` if you use a niche browser.
- `QUERY_ALL_PACKAGES` is declared because the toggle list needs to
  enumerate every launchable app on the device. Play Store flags this
  permission; if you publish, justify it as a "device administration"
  use case or replace the list with a static curated set.

## License

MIT. Use it on your own phone, modify freely, etc.
